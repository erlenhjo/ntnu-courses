# -*- coding: utf-8 -*-
"""
Created on Fri Feb 12 15:42:11 2021

@author: Erlend Johansen
"""

from math import factorial

#print(factorial(10000)) #gikk fint
#print(factorial(100000)) #gikk ikke så bra
#for reelle systemer er man i nærheten av størrelse 10^23 / 1 mol

